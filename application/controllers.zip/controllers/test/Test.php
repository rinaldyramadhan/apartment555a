<?php 

class Test extends CI_Controller{

	public function test_halaman()
	{
		$this->load->view('test/halaman_test');
	}

}

?>