<div class="row">
	<div class="col-xl-12">
		<div class="card">
			<div class="card-header text-center text-white bg-dark">
				<h3>Contact Us</h3>
			</div>
			<div class="card-body bg-dark">
				<div class="row">
					<div class="col-xl-6"	>
						<form>
									
								<div class="card">
									<div class="card-header bg-danger">
										
									</div>
									<div class="card-body">
										<div class="form-group">
											<label for="Nama"><h6>Nama</h6></label>
											<input type="Nama" name="Nama" class="form-control">
										</div>
										<div class="form-group">
											<label for="email"><h6>Email</h6></label>
											<input type="email" name="email" class="form-control">
										</div>
										<div class="form-group">
											<label for="no_telp"><h6>No. Telp</h6></label>
											<input type="tel" name="no_telp" class="form-control">
										</div>
										<div class="form-group">
											<label for="no_telp"><h6>Pesan</h6></label>
											<textarea class="form-control" rows="3"></textarea>
										</div>
										<div class="form-group">
											<button>Kirim</button>
										</div>
									</div>
								</div>
						</form>
					</div>
					<div class="col-xl-6">
						<div class="row">
							<div class="col-xl-12">
								<div class="card p-5 bg-dark text-white">
									<div class="card-header bg-dark">
										
									</div>
									<div class="card-body text-center">
										<div class="p-4">
												<h3>Apartment555</h3> <br>	
												<h4><i class="fas fa-phone"></i> +62 1397 9 180 <br>
													<small>info@apartment555.cm</small> <br> <br>	
													Taman Melati Apartment, Bandung <br>
													Indonesia
												</h4> <br>	

												<h6 class="border bordered">WE MAKE YOU FEELS LIKE @ HOME</h6>
										</div>

									</div>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>		
	</div>	
</div>