<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<table border="">
		<thead>
			<tr>
				<th>Nama</th>
				<th><input type="" name=""></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>PASSWORD</td>
				<td><input type="password" name=""></td>
			</tr>
		</tbody>
	</table>

</body>
</html>