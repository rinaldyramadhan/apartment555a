 <footer class="mt-5">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span >Copyright © Apartment555 - <?php echo date('Y') ?></span>
          </div>
        </div>
      </footer>